# SkillGap AI Backend

## Local setup

Python 3.10+ recommended.

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

API: http://localhost:8000
Swagger docs: http://localhost:8000/docs

POST `/analyze` expects multipart form data:
- `resume`: PDF or DOCX
- `role`: target role

The backend extracts text, detects skills with an alias/taxonomy, computes skill coverage plus TF-IDF semantic similarity, ranks gaps, and returns learning recommendations with estimated hours.

## Production
Deploy this FastAPI service on Render, Railway, Fly.io, or another Python host. Set the frontend `API_BASE` in `assets/app.js` to the deployed API URL.
